<?php

function CreateVouchers($ApiKey,$SecKey,$Amount,$WorthValue,$InvoiceID)
{
    $curl = curl_init();
    
    //Create Security Hash (SHA512) Based on Params and SecKey 
    $SecurityHash = hash_hmac('sha512', $ApiKey . ":" . $SecKey . ":" . $Amount . ":" . $InvoiceID . ":" . $WorthValue, $SecKey);

    $baseUrl = "https://www.premiumvouchers.com/api/vouchers/CreateVouchers?";
    $params = "ApiKey=" . $ApiKey . "&Amount=" . $Amount . "&WorthValue=" . $WorthValue . "&InvoiceID=" . $InvoiceID . "&SecurityHash=" . $SecurityHash;

    curl_setopt_array($curl, array(
        CURLOPT_URL => $baseUrl . $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "",
        CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache"
        )
    ));

    $response = curl_exec($curl);
    $err = curl_error($curl);

    curl_close($curl);

    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo $response;
    }
}

function RedeemVouchers($ApiKey,$SecKey,$VoucherCode,$WorthValue,$InvoiceID)
{
    $curl = curl_init();
    
    //Create Security Hash (SHA512) Based on Params and SecKey
    $SecurityHash = hash_hmac('sha512', $ApiKey . ":" . $SecKey . ":" . $VoucherCode . ":" . $InvoiceID . ":" . $WorthValue, $SecKey);
    
    $baseUrl = "https://www.premiumvouchers.com/api/vouchers/ReturnVouchers?";
    $params = "ApiKey=" . $ApiKey . "&VoucherCode=" . $VoucherCode . "&WorthValue=" . $WorthValue . "&InvoiceID=" . $InvoiceID . "&SecurityHash=" . $SecurityHash;
    
    curl_setopt_array($curl, array(
        CURLOPT_URL => $baseUrl . $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "",
        CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache"
        )
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo $response;
    }
}

function GetBalance($ApiKey)
{
    $curl = curl_init();
    
     
    $baseUrl = "https://www.premiumvouchers.com/api/vouchers/GetBalance?";
    $params = "ApiKey=" . $ApiKey ;
    curl_setopt_array($curl, array(
        CURLOPT_URL => $baseUrl . $params,
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_ENCODING => "",
        CURLOPT_MAXREDIRS => 10,
        CURLOPT_TIMEOUT => 30,
        CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
        CURLOPT_CUSTOMREQUEST => "POST",
        CURLOPT_POSTFIELDS => "",
        CURLOPT_HTTPHEADER => array(
            "cache-control: no-cache"
        )
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
        echo "cURL Error #:" . $err;
    } else {
        echo $response;
    }
}


//Call Examples

//Your APIkey and SecurityKey
$ApiKey = "***Enter APIKey";
$SecKey = "*** Enter SecurityKey ***";

///Params
$Amount = "*** Amount ***";
$WorthValue = "USD";

//Your Website Invoice ID 
$InvoiceID = "*** Enter Invoice Number from Your Website";


//Excute CreateVouchers function
$JsonResult=CreateVouchers($ApiKey,$SecKey,$Amount,$WorthValue,$InvoiceID);

///////////////////////////////////////////////////////////////////////////
//Voucher Code
$VoucherCode="**** Enter your Voucher Code ****" ;

$JsonResult= RedeemVouchers($ApiKey, $SecKey, $VoucherCode, $WorthValue, $InvoiceID);

///////////////////////////////////////////////////////////////////////////
//Execute GetBalance Function
$JsonResult=GetBalance($ApiKey);


















